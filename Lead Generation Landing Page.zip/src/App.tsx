import { Hero } from "./components/Hero";
import { Features } from "./components/Features";
import { Testimonials } from "./components/Testimonials";
import { LeadForm } from "./components/LeadForm";
import { WhyChooseUs } from "./components/WhyChooseUs";
import { Footer } from "./components/Footer";
import { useEffect } from "react";

export default function App() {
  useEffect(() => {
    // Check if script is already loaded
    if (window.google?.maps?.importLibrary) {
      console.log('✅ Google Maps already loaded');
      window.dispatchEvent(new Event('google-maps-loaded'));
      return;
    }

    const existingScript = document.querySelector('script[src*="maps.googleapis.com"]');
    if (existingScript) {
      console.log('⏳ Script tag exists, waiting for load...');
      // Set up a checker for when it loads
      const checkInterval = setInterval(() => {
        if (window.google?.maps?.importLibrary) {
          clearInterval(checkInterval);
          console.log('✅ Google Maps loaded');
          window.dispatchEvent(new Event('google-maps-loaded'));
        }
      }, 100);
      
      return () => clearInterval(checkInterval);
    }

    console.log('🔄 Loading Google Maps API script...');
    
    const script = document.createElement('script');
    // Use loading=async for best practice (no callback parameter)
    script.src = `https://maps.googleapis.com/maps/api/js?key=AIzaSyCRfCb0k0r4h-Zh_1erFF7z29ZGwWklAAw&libraries=places&loading=async`;
    script.async = true;
    script.defer = true;
    
    script.onload = () => {
      console.log('✅ Google Maps script loaded');
      // Wait a bit for the API to fully initialize
      const checkReady = setInterval(() => {
        if (window.google?.maps?.importLibrary) {
          clearInterval(checkReady);
          console.log('✅ Google Maps API ready');
          window.dispatchEvent(new Event('google-maps-loaded'));
        }
      }, 50);
      
      // Cleanup after 5 seconds if not loaded
      setTimeout(() => clearInterval(checkReady), 5000);
    };
    
    script.onerror = (error) => {
      console.error('❌ Failed to load Google Maps API script:', error);
    };
    
    document.head.appendChild(script);

    return () => {
      // Only remove if it's still a child
      try {
        if (script.parentNode === document.head) {
          document.head.removeChild(script);
        }
      } catch (e) {
        // Ignore removal errors
      }
    };
  }, []);

  return (
    <div className="min-h-screen bg-white">
      <LeadForm />
      <Features />
      <Testimonials />
      <WhyChooseUs />
      <Footer />
    </div>
  );
}